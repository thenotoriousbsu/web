const express = require("express");
const fs = require("fs");  
const app = express();
const path = require("path")
 
app.use(express.static(path.join( __dirname,'./dist/lab')));

app.get("/students", function(request, response){
    
    response.header('Access-Control-Allow-Origin', '*');

    response.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');

    response.header('Access-Control-Allow-Methods', 'GET, PATCH, PUT, POST, DELETE, OPTIONS');
     
    const content = fs.readFileSync(__dirname + '/public/data.json', "utf8");

    const users = JSON.parse(content);

    response.send(users);

});
  
app.listen(3000);
