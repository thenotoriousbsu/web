import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

function compare(a, b){
  if (a > b) return 1; 
  if (a == b) return 0; 
  if (a < b) return -1; 
}

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  @Input() users;
  @Input() headers;
  @Input() modal;
  @Input() clickedId;
  @Output() modalChange = new EventEmitter<boolean>();
  @Output() clickedIdChange = new EventEmitter<string>();


  constructor() { }

  ngOnInit(): void {
  }

  delete(id) {
    const i = this.users.findIndex(e => e.id === id)
    this.users.splice(i,1);
  }

  edit(id){
    this.modal = true;
    
    this.modalChange.emit(this.modal);
    
    this.clickedIdChange.emit(id);
  }

  sort(title){
    this.users = this.users.sort((a, b) => compare(a[title], b[title]));
  }
}
