import { Component, OnInit, Input } from '@angular/core';
import { NgModel, NgForm} from '@angular/forms';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  @Input() users;
  @Input() modal;

  constructor() { }

  ngOnInit(): void {
  }

  addUser(form){
    const user = form.value;

    user.id = uuidv4();

    this.users.push(user);

    form.reset();
  }
}
