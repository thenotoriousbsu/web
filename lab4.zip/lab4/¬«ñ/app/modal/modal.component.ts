import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { NgForm} from '@angular/forms';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {
  @Input() users: any[];
  @Input() modal: boolean;
  @Input() clickedId: string;
  @Output() modalChange = new EventEmitter<boolean>();
  i: number;

  constructor() { 
  }

  ngOnInit(): void {
    this.i = this.users.findIndex(e => e.id === this.clickedId)
  }

  close(){
    this.modal = false;
    this.modalChange.emit(this.modal);
  }

  editUser(form){
    if(form.value.name == '' || form.value.mark == ''){
      return;
    }
    this.users[this.i].name = form.value.name;
    this.users[this.i].mark = form.value.mark;
    this.close();
  }
}
