import { Component, Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable()
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  users;
  headers;
  modal = false;
  clickedId;

  constructor(private http: HttpClient){
    this.http.get('http://localhost:3000/students')
    .subscribe((res) => {
      this.users = res;
      this.headers = Object.keys(this.users[0]);
      
    })
  } 

  avgMark(){
    return this.users.reduce((res, e) => res + (e.mark), 0) / this.users.length;
  }
}
