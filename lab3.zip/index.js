const items = [];
const keys = [];

init();

function init(){
    $.ajax({
        url: 'https://jsonplaceholder.typicode.com/todos/?userId=1',
        dataTypes: 'json',
        success: function getData(data, textStatus){
            data.forEach(e => items.push(e));
            items.map((e) => {
                delete e.userId;
            });
            drawHeaders();
            drawBody();
            drawForm();
            deleteItem();
            sortBtns();
        },
        error: function err(data){
            $('body').text(data.statusText);
        }
    });
}

function sortBtns(){
    keys.forEach(e => {
        if(e !== 'id') $('#buttons').append($(`<button id='${e}'>sort ${e}</button>`));
    });

    $('#buttons').children().toArray().forEach(e => $(e).click(sort));
}

function sort(e){
    for (let i = 0; i < items.length; i++) {
        for (let j = 0; j < items.length - 1; j++) {
            if(items[j][$(e.target).attr('id')] > items[j + 1][$(e.target).attr('id')]) {
                [items[j][$(e.target).attr('id')], items[j+1][$(e.target).attr('id')]] = [items[j+1][$(e.target).attr('id')], items[j][$(e.target).attr('id')]];
            }
        }    
    }

    drawBody();
}

function drawHeaders(){
    for (const key in items[0]) {
        $('#thead').append($(`<th>${key}</th>`));
        keys.push(key);
    }
}

function drawBody(){
    $('#tbody').empty();

    items.forEach(e => {
        const tr = $('<tr></tr>');

        for (const key in e) {
            tr.append($(`<td>${e[key]}</td>`));
            if(key === 'completed'){
                tr.css({
                    background: e[key] ? 'green' : 'red'
                });
            }
        }

        tr.append($('<td data-delete="true"></td>').html('&times;'));

        $('#tbody').append(tr);
    });
}

function drawForm(){
    for (const key in items[0]) {
        if(key !== 'id')
            $('#form').append(key === 'title' 
                                        ? $(`<input type='text' placeholder='${key}' required/>`) 
                                        : $('<select><option>false</option><option>true</option></select>'));
    }

    $('#form').append('<input type="submit" placeholder="${key}" id="submit"/>');
    $('#form').submit(addItem);
}

function addItem(e){
    e.preventDefault();

    const formItems = [...e.target];
    const newItem = {};
    
    keys.forEach((e) => {
        switch (e) {
            case 'id':
                newItem[e] = setId();
                break;
            case 'title':
                newItem[e] = formItems[0].value;
                formItems[0].value = '';
                break;
            case 'completed':
                newItem[e] = formItems[1].value === 'true';
                break;
        }
    });

    items.push(newItem);
    addItemToBody(newItem);
}

function setId(){
    let i = 1 + Math.floor(Math.random() * (items.length + 1))


    while(items.findIndex(e => e.id == i) >= 0){
        i = 1 + Math.floor(Math.random() * (items.length + 1))
    }

    return i;
}

function addItemToBody(item){
    const tr = $('<tr></tr>');

    keys.forEach(e => {
        tr.append($(`<td>${item[e]}</td>`));
            if(e === 'completed'){
                tr.css({
                    background: item[e] ? 'green' : 'red'
                });
            }
    });

    tr.append($('<td></td>').html('&times;'));

    $('#tbody').append(tr);
}

function deleteItem(){
    $('#tbody').click((e) => {
        if($(e.target).attr('data-delete') === 'true'){
            let id = $($(e.target).parent().children()[0]).text();          

            let i = items.findIndex(e => e.id == id);

            items.splice(i, 1);

            drawBody();
        }
    });
}


