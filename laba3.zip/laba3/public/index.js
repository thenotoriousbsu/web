let items;
const keys = [];

init();

function init(){
    console.log(1)
    $.ajax({
        url: '/api/users',
        dataTypes: 'jsonp',
        success: function getData(data, textStatus){
            items = data;
            drawHeaders();
            drawBody();
            drawForm();
            deleteItem();
            sortBtns();
            stats();
        },
        error: function err(data){
            console.log(data);    
        }
    });
}

function sortBtns(){
    keys.forEach(e => {
        if(e !== 'id') $('#buttons').append($(`<button id='${e}'>sort ${e}</button>`));
    });

    $('#buttons').children().toArray().forEach(e => $(e).click(sort));
}

function sort(e){
    for (let i = 0; i < items.length; i++) {
        for (let j = 0; j < items.length - 1; j++) {
            if($(e.target).attr('id') == 'mark'){
                if(Number(items[j][$(e.target).attr('id')]) > Number(items[j + 1][$(e.target).attr('id')])) {
                    [items[j], items[j+1]] = [items[j+1], items[j]];
                }
            }
            else if(items[j][$(e.target).attr('id')] > items[j + 1][$(e.target).attr('id')]) {
                [items[j], items[j+1]] = [items[j+1], items[j]];
            }
        }    
    }

    drawBody();
}

function drawHeaders(){
    for (const key in items[0]) {
        $('#thead').append($(`<th>${key}</th>`));
        keys.push(key);
    }
}

function drawBody(){
    $('#tbody').empty();

    items.forEach(e => {
        const tr = $('<tr></tr>');

        for (const key in e) {
            tr.append($(`<td>${e[key]}</td>`));
        }

        tr.append($('<td data-delete="true"></td>').html('&times;'));

        $('#tbody').append(tr);
    });

    stats();
}

function drawForm(){
    for (const key in items[0]) {
        if(key !== 'id')
            $('#form').append(key !== 'mark' 
                                        ? $(`<input type='text' placeholder='${key}' required/>`) 
                                        : $(`<input type='number' min='1' max='10' placeholder='${key}' required/>`));
    }

    $('#form').append('<input type="submit" placeholder="${key}" id="submit"/>');
    $('#form').submit(addItem);
}

function addItem(e){
    e.preventDefault();

    const formItems = [...e.target];
    const newItem = {};
    
    keys.forEach((e) => {
        switch (e) {
            case 'id':
                newItem[e] = uuidv4();
                break;
            case 'name':
                newItem[e] = formItems[0].value;
                formItems[0].value = '';
                break;
            case 'mark':
                newItem[e] = Math.abs(formItems[1].value);
                formItems[1].value = '';
                break;
        }
    });

    items.push(newItem);
    addItemToBody(newItem);
}

function uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

function addItemToBody(item){
    const tr = $('<tr></tr>');

    keys.forEach(e => {
        tr.append($(`<td>${item[e]}</td>`));
    });

    tr.append($('<td></td>').html('&times;'));

    $('#tbody').append(tr);
    stats();
}

function deleteItem(){
    $('#tbody').click((e) => {
        if($(e.target).attr('data-delete') === 'true'){
            let id = $($(e.target).parent().children()[0]).text();          

            let i = items.findIndex(e => e.id == id);

            items.splice(i, 1);

            drawBody();
        }
    });
}

function stats(){
    let avgMarks = 0;

    $('tr').toArray().forEach((e) => {
        $(e).children().toArray().forEach((el, i) => {
            !((i+1) % 3) ? avgMarks += Number($(el).text()) : null;
        })
    });

    $('#stats').text(`${(avgMarks / items.length)}`);
}


